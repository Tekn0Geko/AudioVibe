/**
 * Equalizer Module - Handles audio equalization and audio processing
 */
const EqualizerManager = (function() {
    // Audio context and nodes
    let audioContext = null;
    let sourceNode = null;
    let analyserNode = null;
    let gainNode = null;
    
    // Equalizer bands (frequencies in Hz)
    const bands = [
        { name: 'bass', freq: 60, gain: 0, filter: null },
        { name: 'lowMid', freq: 170, gain: 0, filter: null },
        { name: 'mid', freq: 350, gain: 0, filter: null },
        { name: 'highMid', freq: 1000, gain: 0, filter: null },
        { name: 'treble', freq: 3500, gain: 0, filter: null },
        { name: 'presence', freq: 10000, gain: 0, filter: null }
    ];
    
    /**
     * Initialize the audio context and equalizer
     * @param {HTMLAudioElement} audioElement - The audio element to process
     */
    function init(audioElement) {
        try {
            // Create audio context if Web Audio API is supported
            if (window.AudioContext || window.webkitAudioContext) {
                audioContext = new (window.AudioContext || window.webkitAudioContext)();
                
                // Create source node from audio element
                sourceNode = audioContext.createMediaElementSource(audioElement);
                
                // Create analyser node for visualizations
                analyserNode = audioContext.createAnalyser();
                analyserNode.fftSize = 2048;
                
                // Create main gain node
                gainNode = audioContext.createGain();
                gainNode.gain.value = 1.0;
                
                // Setup equalizer bands with biquad filters
                setupEqualizer();
                
                // Connect the audio processing chain:
                // Audio Element -> Source Node -> EQ Filters -> Gain Node -> Analyser -> Audio Context Destination
                let lastNode = sourceNode;
                
                // Connect through each filter
                bands.forEach(band => {
                    lastNode.connect(band.filter);
                    lastNode = band.filter;
                });
                
                // Complete the chain
                lastNode.connect(gainNode);
                gainNode.connect(analyserNode);
                analyserNode.connect(audioContext.destination);
                
                console.log("Equalizer initialized successfully");
            } else {
                console.error("Web Audio API is not supported in this browser");
            }
        } catch (error) {
            console.error("Error initializing equalizer:", error);
        }
    }
    
    /**
     * Setup equalizer filters
     */
    function setupEqualizer() {
        // Create filters for each band
        bands.forEach(band => {
            // Create a biquad filter for this band
            band.filter = audioContext.createBiquadFilter();
            
            // Set filter type based on frequency range
            if (band.freq < 100) {
                band.filter.type = 'lowshelf'; // Bass range
            } else if (band.freq > 5000) {
                band.filter.type = 'highshelf'; // Treble range
            } else {
                band.filter.type = 'peaking'; // Mid range
            }
            
            // Set filter parameters
            band.filter.frequency.value = band.freq;
            band.filter.gain.value = band.gain;
            band.filter.Q.value = 1.0; // Quality factor
        });
    }
    
    /**
     * Adjust the gain of a specific equalizer band
     * @param {string} bandName - Name of the band to adjust
     * @param {number} gainValue - Gain value in dB (-12 to +12)
     */
    function adjustBand(bandName, gainValue) {
        const band = bands.find(b => b.name === bandName);
        if (band && band.filter) {
            band.gain = gainValue;
            band.filter.gain.value = gainValue;
            console.log(`Adjusted ${bandName} band to ${gainValue}dB`);
            return true;
        }
        return false;
    }
    
    /**
     * Reset all equalizer bands to 0 dB (flat response)
     */
    function resetEqualizer() {
        bands.forEach(band => {
            if (band.filter) {
                band.gain = 0;
                band.filter.gain.value = 0;
            }
        });
        console.log("Equalizer reset to flat response");
    }
    
    /**
     * Apply a preset equalizer setting
     * @param {string} presetName - Name of the preset to apply
     */
    function applyPreset(presetName) {
        // Define some common EQ presets
        const presets = {
            flat: [0, 0, 0, 0, 0, 0],
            bass: [8, 2, 0, 0, 0, 0],
            rock: [4, 2, -2, -2, 2, 3],
            pop: [-2, 0, 0, 2, 4, 3],
            classical: [3, 2, 0, 0, 2, 5],
            jazz: [3, 2, -1, -2, 1, 4],
            electronic: [4, 2, 0, -2, 3, 4]
        };
        
        // Get preset gains or default to flat
        const gains = presets[presetName] || presets.flat;
        
        // Apply gains to bands
        bands.forEach((band, index) => {
            if (band.filter && index < gains.length) {
                band.gain = gains[index];
                band.filter.gain.value = gains[index];
            }
        });
        
        console.log(`Applied ${presetName} equalizer preset`);
    }
    
    /**
     * Get the current state of all equalizer bands
     * @returns {Array} - Array of band objects with name, freq, and gain values
     */
    function getBandSettings() {
        return bands.map(band => ({
            name: band.name,
            freq: band.freq,
            gain: band.gain
        }));
    }
    
    /**
     * Get the analyser node for visualizations
     * @returns {AnalyserNode} - The audio analyser node
     */
    function getAnalyser() {
        return analyserNode;
    }
    
    /**
     * Clean up resources when no longer needed
     */
    function cleanup() {
        if (audioContext) {
            // Disconnect all nodes
            if (sourceNode) sourceNode.disconnect();
            bands.forEach(band => {
                if (band.filter) band.filter.disconnect();
            });
            if (gainNode) gainNode.disconnect();
            if (analyserNode) analyserNode.disconnect();
            
            // Close audio context if possible
            if (audioContext.state !== 'closed' && audioContext.close) {
                audioContext.close();
            }
            
            console.log("Equalizer resources cleaned up");
        }
    }
    
    // Public API
    return {
        init,
        adjustBand,
        resetEqualizer,
        applyPreset,
        getBandSettings,
        getAnalyser,
        cleanup
    };
})();