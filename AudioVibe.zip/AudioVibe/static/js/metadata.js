/**
 * Metadata Module - Handles extraction of audio file metadata
 */
const MetadataManager = (function() {
    // Cache for metadata to avoid re-parsing files
    const metadataCache = new Map();
    
    /**
     * Extract metadata from an audio file
     * @param {File} file - The audio file to parse
     * @returns {Promise<Object>} - Promise resolving to metadata object
     */
    async function extractMetadata(file) {
        console.log("Starting metadata extraction for:", file.name);
        
        // Return cached metadata if available
        if (metadataCache.has(file.name)) {
            console.log("Using cached metadata for:", file.name);
            return metadataCache.get(file.name);
        }
        
        // Get duration from audio element using a Promise
        const duration = await getDuration(file);
        console.log("Audio duration:", duration);
        
        // Basic metadata using just the filename
        const basicMetadata = {
            title: file.name.replace(/\.[^/.]+$/, ""),
            artist: "Unknown Artist",
            artistList: ["Unknown Artist"],
            album: "Unknown Album",
            duration: duration,
            picture: null
        };
        
        // Store basic metadata in cache right away in case tag reading fails
        metadataCache.set(file.name, basicMetadata);
        
        // Verify jsmediatags is available
        if (typeof jsmediatags === 'undefined') {
            console.error("jsmediatags library not available!");
            return basicMetadata;
        }
        
        // Try to extract ID3 tags
        try {
            // Parse tags with jsmediatags
            return new Promise((resolve) => {
                jsmediatags.read(file, {
                    onSuccess: function(tag) {
                        try {
                            console.log("Successfully read tags:", tag);
                            console.log("Artist tag:", tag.tags.artist, "Type:", typeof tag.tags.artist);
                            
                            // Store all raw tag data for debugging
                            const rawTags = {
                                title: tag.tags.title,
                                artist: tag.tags.artist,
                                album: tag.tags.album,
                                genre: tag.tags.genre,
                                year: tag.tags.year,
                                track: tag.tags.track,
                                composer: tag.tags.composer,
                                comment: tag.tags.comment,
                                // Add any other tag fields that might contain artist information
                                performer: tag.tags.performer,
                                albumartist: tag.tags.albumartist,
                                artists: tag.tags.artists
                            };
                            
                            console.log("Raw tag data:", rawTags);
                            
                            // Extract basic metadata
                            let artistList;
                            
                            // Use multiple approaches to extract artists and combine them
                            // 1. Try direct extraction from all tag fields first
                            const directArtists = directExtractArtists(tag.tags);
                            console.log("Direct artist extraction:", directArtists);
                            
                            // 2. Try traditional parsing as fallback
                            const parsedArtists = processArtistField(tag.tags.artist, file.name);
                            console.log("Parsed artists:", parsedArtists);
                            
                            // 3. Combine both approaches (direct method takes precedence if it found anything)
                            if (directArtists && directArtists.length > 0) {
                                artistList = directArtists;
                                console.log("Using direct artist extraction");
                            } else {
                                artistList = parsedArtists;
                                console.log("Using parsed artists");
                            }
                            
                            // Prioritize album artist if available
                            let displayArtist = basicMetadata.artist;
                            if (tag.tags.albumartist) {
                                displayArtist = tag.tags.albumartist;
                                console.log("Using album artist:", displayArtist);
                            } else if (tag.tags.artist) {
                                displayArtist = tag.tags.artist;
                                console.log("Using track artist:", displayArtist);
                            }
                            
                            const result = {
                                title: tag.tags.title || basicMetadata.title,
                                // Handle multiple artists (could be string or array already depending on the tag format)
                                artist: displayArtist, 
                                // Store original artist data for multiple artists support
                                artistList: artistList,
                                album: tag.tags.album || basicMetadata.album,
                                albumArtist: tag.tags.albumartist || null,
                                duration: duration,
                                picture: null
                            };
                            
                            // Extract cover art if available
                            if (tag.tags.picture) {
                                try {
                                    // For small images, use the direct approach
                                    const { data, format } = tag.tags.picture;
                                    let binary = '';
                                    const bytes = new Uint8Array(data);
                                    const len = bytes.byteLength;
                                    
                                    // Process in chunks to avoid call stack size limits
                                    for (let i = 0; i < len; i++) {
                                        binary += String.fromCharCode(bytes[i]);
                                    }
                                    
                                    result.picture = `data:${format};base64,${window.btoa(binary)}`;
                                    console.log("Cover art found");
                                } catch (e) {
                                    console.error("Error converting cover art:", e);
                                }
                            }
                            
                            // Update cache with full metadata
                            metadataCache.set(file.name, result);
                            resolve(result);
                        } catch (parseError) {
                            console.error("Error parsing tag data:", parseError);
                            resolve(basicMetadata);
                        }
                    },
                    onError: function(error) {
                        console.error("Error reading tags:", error);
                        resolve(basicMetadata);
                    }
                });
            });
        } catch (error) {
            console.error("Failed to parse metadata:", error);
            return basicMetadata;
        }
    }
    
    /**
     * Get audio duration from file
     * @param {File} file - Audio file
     * @returns {Promise<number>} - Duration in seconds
     */
    function getDuration(file) {
        return new Promise((resolve) => {
            try {
                const audioEl = document.createElement('audio');
                const objectUrl = URL.createObjectURL(file);
                audioEl.src = objectUrl;
                
                let resolved = false;
                
                // Try to get duration when metadata is loaded
                audioEl.addEventListener('loadedmetadata', () => {
                    if (!resolved) {
                        const duration = audioEl.duration;
                        console.log(`Duration loaded for ${file.name}: ${duration}`);
                        URL.revokeObjectURL(objectUrl);
                        resolved = true;
                        resolve(duration);
                    }
                });
                
                // Handle errors and make sure we resolve something
                audioEl.addEventListener('error', () => {
                    if (!resolved) {
                        console.error(`Error loading audio for ${file.name}`, audioEl.error);
                        URL.revokeObjectURL(objectUrl);
                        resolved = true;
                        resolve(0);
                    }
                });
                
                // Fallback in case the events don't fire
                setTimeout(() => {
                    if (!resolved) {
                        console.warn(`Timeout getting duration for ${file.name}`);
                        URL.revokeObjectURL(objectUrl);
                        resolved = true;
                        resolve(0);
                    }
                }, 3000);
            } catch (error) {
                console.error("Error getting duration:", error);
                resolve(0);
            }
        });
    }
    
    /**
     * Format duration in seconds to MM:SS format
     * @param {number} seconds - Duration in seconds
     * @returns {string} - Formatted time string
     */
    function formatTime(seconds) {
        if (!seconds || isNaN(seconds)) return "0:00";
        
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
    
    /**
     * Special case for files with multiple artists in one string
     * @param {string} filename - Name of the file
     * @param {string} artistStr - Artist string to possibly parse differently
     * @returns {Array|null} - Array of artists if special case detected, null otherwise
     */
    function checkForSpecialArtistCases(filename, artistStr) {
        console.log("Checking filename for artist collaborations:", filename);
        
        // Extract the filename without extension and split by spaces, dashes, underscores
        const filenameParts = filename.replace(/\.[^/.]+$/, "")
            .toLowerCase()
            .replace(/[_-]/g, " ")
            .split(" ");
            
        // Common featuring words and conjunctions that might indicate collaborations
        const featuringTerms = ["feat", "ft", "featuring", "with", "x", "vs", "versus"];
        const ampersandForms = ["&", "and", "+"];
        
        // Check if artistStr is in the filename
        const artistInFilename = filenameParts.some(part => 
            artistStr.toLowerCase().includes(part) || part.includes(artistStr.toLowerCase()));
            
        if (artistInFilename) {
            // Check for common collaborator patterns in filename
            for (const term of [...featuringTerms, ...ampersandForms]) {
                const termIndex = filenameParts.indexOf(term);
                if (termIndex !== -1 && termIndex > 0 && termIndex < filenameParts.length - 1) {
                    // Found a featuring term with words before and after
                    const beforeTerm = filenameParts.slice(0, termIndex).join(" ");
                    const afterTerm = filenameParts.slice(termIndex + 1).join(" ");
                    
                    // Verify neither part is empty or very short
                    if (beforeTerm.length > 1 && afterTerm.length > 1) {
                        console.log(`Special case: collaboration with "${term}" between "${beforeTerm}" and "${afterTerm}"`);
                        return [artistStr, afterTerm];
                    }
                }
            }
        }
        
        // Some FLAC files with multiple artists might not use standard separators
        if (filename.toLowerCase().endsWith('.flac')) {
            console.log("Special case check for FLAC file:", filename);
            
            // Special case for the "Summer Walker, 21 Savage" pattern
            if (artistStr === "Summer Walker") {
                if (filename.toLowerCase().includes("21 savage") || 
                    filename.toLowerCase().includes("21-savage") || 
                    filename.toLowerCase().includes("21savage")) {
                    console.log("Special case detected: Summer Walker + 21 Savage");
                    return ["Summer Walker", "21 Savage"];
                }
            }
            
            // Extract numbers and potential artist names from filename
            const potentialArtistNames = filenameParts.filter(part => {
                // Filter out common noise words
                const noiseWords = ["the", "a", "an", "of", "in", "on", "at", "by", "for", "with"];
                return part.length > 1 && !noiseWords.includes(part) && isNaN(parseInt(part));
            });
            
            // If artistStr is found in potential artist names, and there are others
            if (potentialArtistNames.length > 1) {
                const artistStrLower = artistStr.toLowerCase();
                const matchedNameIndex = potentialArtistNames.findIndex(name => 
                    artistStrLower.includes(name) || name.includes(artistStrLower));
                
                if (matchedNameIndex !== -1) {
                    // Get other potential artists from filename
                    const otherNames = potentialArtistNames.filter((_, i) => i !== matchedNameIndex);
                    
                    if (otherNames.length > 0) {
                        // If the filename is longer than 15 characters and contains parts of the artistStr
                        // it's more likely to be a valid collaboration
                        if (filename.length > 15 && filename.toLowerCase().includes(artistStr.toLowerCase().substring(0, 5))) {
                            console.log("Detected potential collaboration from filename:", [artistStr, ...otherNames]);
                            return [artistStr, ...otherNames.map(n => n.charAt(0).toUpperCase() + n.slice(1))];
                        }
                    }
                }
            }
        }
        
        // Check if the artist string contains an indication of collaboration
        // but the current parsing didn't catch it
        for (const term of ["feat", "ft", "with", "and", "&", "x"]) {
            if (artistStr.toLowerCase().includes(` ${term} `) || 
                artistStr.toLowerCase().includes(`(${term} `) ||
                artistStr.toLowerCase().includes(`(${term}. `)) {
                // If we detect a term but our parsing didn't split it, force a split
                const parts = artistStr.split(new RegExp(`\\s*(?:\\()?${term}(?:\\.|\\s|\\))+\\s*`, 'i'));
                if (parts.length > 1) {
                    const cleanParts = parts.map(p => p.trim().replace(/^\(|\)$/g, '')).filter(Boolean);
                    if (cleanParts.length > 1) {
                        console.log("Forced split of artist string with term:", term, cleanParts);
                        return cleanParts;
                    }
                }
            }
        }
        
        return null;
    }
    
    /**
     * Process artist field to handle multiple artists
     * @param {string|Array} artistData - Artist data from tags
     * @param {string} [filename] - Optional filename for special case detection
     * @returns {Array} - Array of artist names
     */
    function processArtistField(artistData, filename) {
        console.log("Processing artist data:", artistData, "Filename:", filename);
        
        if (!artistData) {
            console.log("No artist data, using Unknown Artist");
            return ["Unknown Artist"];
        }
        
        // If it's already an array, return it
        if (Array.isArray(artistData)) {
            console.log("Artist data is already an array:", artistData);
            return artistData;
        }
        
        // Split string by common separators
        const artistStr = String(artistData);
        console.log("Artist string:", artistStr);
        
        // Check for special cases first if filename is provided
        if (filename) {
            const specialCaseResult = checkForSpecialArtistCases(filename, artistStr);
            if (specialCaseResult) {
                console.log("Using special case for", filename, ":", specialCaseResult);
                return specialCaseResult;
            }
        }
        
        // Try to parse as JSON if it looks like a JSON string
        // Some MP3 tags might store arrays as JSON strings
        if (artistStr.startsWith('[') && artistStr.endsWith(']')) {
            try {
                const parsedArray = JSON.parse(artistStr);
                if (Array.isArray(parsedArray)) {
                    console.log("Parsed JSON array from artist string:", parsedArray);
                    return parsedArray.filter(Boolean);
                }
            } catch (e) {
                console.log("Not a valid JSON array", e);
                // Continue with normal parsing
            }
        }
        
        // Multiple layers of processing - combine all approaches
        let allArtists = [];
        let remainingStr = artistStr;
        
        // First check for featured artists pattern
        // This has to be handled specially because it's not a symmetric pattern
        if (/\s+(?:feat\.?|ft\.?|featuring)\s+/i.test(remainingStr)) {
            console.log("Processing featuring pattern");
            
            // Make sure this is actually a featuring pattern and not an artist with "feat" in their name
            // The pattern should be: [artist] feat. [other artist]
            const featMatch = remainingStr.match(/^(.+?)\s+(?:feat\.?|ft\.?|featuring)\s+(.+)$/i);
            if (featMatch) {
                const [_, mainArtist, featuredArtists] = featMatch;
                
                // Only treat as featuring if:
                // 1. The part before "feat." doesn't contain "feat." itself
                // 2. There's substantial text before and after "feat."
                if (!mainArtist.match(/feat\.?|ft\.?|featuring/i) && 
                    mainArtist.trim().length > 2 && 
                    featuredArtists.trim().length > 2) {
                    
                    console.log("Main artist:", mainArtist, "Featured:", featuredArtists);
                    
                    // Add main artist
                    allArtists.push(mainArtist.trim());
                    
                    // Process featured artists - might have multiple artists
                    remainingStr = featuredArtists;
                } else {
                    console.log("Found 'feat' but doesn't seem to be a featuring pattern");
                }
            }
        }

        // Check specifically for semicolons first, as you mentioned this is the format used
        if (remainingStr.includes(';')) {
            console.log("Found semicolon separator");
            const parts = remainingStr.split(';');
            const cleanParts = parts.map(p => p.trim()).filter(Boolean);
            
            if (allArtists.length === 0) {
                // If we haven't processed any artists yet, use all parts
                allArtists = cleanParts;
            } else {
                // Otherwise, add these parts to our existing list
                allArtists = [...allArtists, ...cleanParts];
            }
            
            // We've processed the string, so clear it
            remainingStr = "";
        }
        
        // Process remaining string with other separators if needed
        // Priority order: comma, ampersand with spaces, x, and, with, basic ampersand
        const separators = [
            { regex: /,\s*/, name: "comma" },
            { regex: /\s+&\s+/, name: "ampersand with spaces" },
            { regex: /\s+x\s+/i, name: "x" },
            { regex: /\s+and\s+/i, name: "and" },
            { regex: /\s+with\s+/i, name: "with" },
            { regex: /&/, name: "basic ampersand" }
        ];
        
        for (const { regex, name } of separators) {
            if (regex.test(remainingStr)) {
                console.log(`Found ${name} separator`);
                const parts = remainingStr.split(regex);
                const cleanParts = parts.map(p => p.trim()).filter(Boolean);
                
                if (allArtists.length === 0) {
                    // If we haven't processed any artists yet, use all parts
                    allArtists = cleanParts;
                } else {
                    // Otherwise, add these parts to our existing list
                    allArtists = [...allArtists, ...cleanParts];
                }
                
                // We've processed the string, so clear it
                remainingStr = "";
                break;
            }
        }
        
        // If we still have an unprocessed string, add it as a single artist
        if (remainingStr && allArtists.length === 0) {
            console.log("No separators found, using as single artist");
            allArtists = [remainingStr.trim()];
        }
        
        // Final cleanup - deduplicate and ensure no empty entries
        const result = [...new Set(allArtists)].filter(Boolean);
        console.log("Final artist list:", result);
        return result.length ? result : ["Unknown Artist"];
    }
    
    /**
     * Format artist list for display
     * @param {Array} artistList - Array of artists
     * @returns {string} - Formatted artist string
     */
    function formatArtistList(artistList) {
        if (!artistList || artistList.length === 0) return "Unknown Artist";
        if (artistList.length === 1) return artistList[0];
        
        // Log full artist list for debugging
        console.log("Formatting artist list:", artistList);
        
        // Simply join all artists with a comma and space
        return artistList.join(', ');
    }
    
    /**
     * Direct extraction of artists from raw tag data
     * @param {Object} tags - Raw tag data object
     * @returns {Array} - Array of artist names
     */
    function directExtractArtists(tags) {
        const artists = [];
        
        // Prioritize album artist if available
        if (tags.albumartist) {
            if (typeof tags.albumartist === 'string') {
                // If albumartist is specified, use it first
                artists.push(tags.albumartist);
                console.log("Added album artist (primary):", tags.albumartist);
            } else if (Array.isArray(tags.albumartist)) {
                artists.push(...tags.albumartist);
                console.log("Added album artists array (primary):", tags.albumartist);
            }
        }
        
        // Check main artist field
        if (tags.artist) {
            if (typeof tags.artist === 'string' && tags.artist.includes(';')) {
                // Split by semicolons which are often used as separators
                const parts = tags.artist.split(';').map(a => a.trim()).filter(Boolean);
                artists.push(...parts);
                console.log("Added artists from semicolon split:", parts);
            } else if (Array.isArray(tags.artist)) {
                // Some formats store as array already
                artists.push(...tags.artist);
                console.log("Added artists from array:", tags.artist);
            } else if (typeof tags.artist === 'string' && !artists.includes(tags.artist)) {
                // Single artist, add if not already in the list
                artists.push(tags.artist);
                console.log("Added single artist:", tags.artist);
            }
        }
        
        // Check additional artist fields that might exist
        if (tags.artists && Array.isArray(tags.artists)) {
            const newArtists = tags.artists.filter(a => !artists.includes(a));
            if (newArtists.length) {
                console.log("Added additional artists from array:", newArtists);
                artists.push(...newArtists);
            }
        } else if (tags.artists && typeof tags.artists === 'string' && !artists.includes(tags.artists)) {
            artists.push(tags.artists);
            console.log("Added additional artist string:", tags.artists);
        }
        
        if (tags.performer && typeof tags.performer === 'string' && !artists.includes(tags.performer)) {
            artists.push(tags.performer);
            console.log("Added performer:", tags.performer);
        }
        
        // Filter duplicates and empty entries
        return [...new Set(artists)].filter(Boolean);
    }
    
    /**
     * Clean up cache
     */
    function cleanupCache() {
        metadataCache.clear();
    }
    
    // Public API
    return {
        extractMetadata,
        formatTime,
        cleanupCache,
        formatArtistList,
        processArtistField,
        checkForSpecialArtistCases,
        directExtractArtists
    };
})();
