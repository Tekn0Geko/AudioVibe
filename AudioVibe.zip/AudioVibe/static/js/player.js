/**
 * Player Module - Handles audio playback functionality
 */
const PlayerManager = (function() {
    // Audio element
    const audioElement = document.getElementById('audio-player');
    
    // Control elements
    const playPauseBtn = document.getElementById('play-pause-btn');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const rewindBtn = document.getElementById('rewind-btn');
    const forwardBtn = document.getElementById('forward-btn');
    const volumeSlider = document.getElementById('volume-slider');
    const progressBar = document.getElementById('progress-bar');
    const progressContainer = document.querySelector('.progress');
    const currentTimeElement = document.getElementById('current-time');
    const totalTimeElement = document.getElementById('total-time');
    
    // Display elements
    const songTitleElement = document.getElementById('song-title');
    const songArtistElement = document.getElementById('song-artist');
    const songAlbumElement = document.getElementById('song-album');
    const albumArtElement = document.getElementById('album-art');
    
    // Player state
    let isPlaying = false;
    let currentTrack = null;
    let equalizerInitialized = false;
    
    // Initialize player
    function init() {
        // Add event listeners
        playPauseBtn.addEventListener('click', togglePlayPause);
        prevBtn.addEventListener('click', playPrevious);
        nextBtn.addEventListener('click', playNext);
        rewindBtn.addEventListener('click', rewind);
        forwardBtn.addEventListener('click', fastForward);
        volumeSlider.addEventListener('input', updateVolume);
        
        // Progress bar interactions - use mousedown for dragging
        progressContainer.addEventListener('mousedown', handleProgressMouseDown);
        
        // Audio element events
        audioElement.addEventListener('timeupdate', updateProgress);
        audioElement.addEventListener('ended', handleTrackEnd);
        audioElement.addEventListener('canplay', enablePlayback);
        audioElement.addEventListener('error', handleError);
        
        // Set initial volume and update visual indicator
        audioElement.volume = volumeSlider.value;
        const volumePercentage = volumeSlider.value * 100;
        volumeSlider.style.setProperty('--volume-percentage', `${volumePercentage}%`);
        
        // Initialize equalizer when user interacts with player
        document.addEventListener('click', initializeEqualizer, { once: true });
    }
    
    /**
     * Initialize the audio equalizer
     * Most browsers require user interaction before allowing AudioContext creation
     */
    function initializeEqualizer() {
        if (!equalizerInitialized) {
            try {
                // Initialize the equalizer with our audio element
                EqualizerManager.init(audioElement);
                equalizerInitialized = true;
                console.log("Equalizer initialized on first user interaction");
                
                // Apply default flat preset
                EqualizerManager.applyPreset('flat');
                
                // Initialize equalizer UI controls if they exist
                if (typeof initializeEqualizerControls === 'function') {
                    initializeEqualizerControls();
                }
                
                // Initialize visualizer if canvas element exists
                const visualizerCanvas = document.getElementById('audio-visualizer');
                if (visualizerCanvas && VisualizerManager) {
                    // Get analyzer node from equalizer
                    const analyserNode = EqualizerManager.getAnalyser();
                    if (analyserNode) {
                        // Initialize and start visualizer
                        if (VisualizerManager.init(visualizerCanvas, analyserNode)) {
                            VisualizerManager.start();
                            console.log("Visualizer initialized and started");
                        }
                    }
                }
            } catch (error) {
                console.error("Failed to initialize equalizer or visualizer:", error);
            }
        }
    }
    
    /**
     * Load and play a track
     * @param {Object} track - The track object with metadata and file
     */
    function loadAndPlayTrack(track) {
        if (!track || !track.file) {
            console.error("Failed to open track - invalid track or missing file");
            UIManager.showNotification("Failed to open track", "error");
            return;
        }
        
        try {
            // If visualizer is enabled, restart it for the new track
            if (VisualizerManager && equalizerInitialized) {
                // Temporarily stop visualizer during track change
                VisualizerManager.stop();
                
                // Start it again after a short delay
                setTimeout(() => {
                    VisualizerManager.start();
                }, 100);
            }
            
            // Store current track
            currentTrack = track;
            
            // Create object URL for the file
            const objectUrl = URL.createObjectURL(track.file);
            
            // Set audio source
            audioElement.src = objectUrl;
            audioElement.load();
            
            // Update UI with track info
            updateTrackInfo(track);
            
            // Try to play (may be blocked by browser autoplay policies)
            play().catch(error => {
                console.error("Playback prevented by browser:", error);
                // Enable the play button so user can manually start playback
                enableControls();
            });
            
            // Don't revoke the objectURL in the onended handler
            // as it prevents the next track from playing correctly
        } catch (error) {
            console.error("Error loading track:", error);
            UIManager.showNotification("Error loading track: " + error.message, "error");
        }
    }
    
    /**
     * Show loading shimmer effect for track metadata
     */
    function showLoadingState() {
        // Clear current content and show loading placeholders
        songTitleElement.innerHTML = '<div class="loading-placeholder title shimmer"></div>';
        songArtistElement.innerHTML = '<div class="loading-placeholder artist shimmer"></div>';
        songAlbumElement.innerHTML = '<div class="loading-placeholder album shimmer"></div>';
        
        // Reset album art to a loading state
        albumArtElement.innerHTML = `<div class="loading-placeholder shimmer" style="width: 100%; height: 100%;"></div>`;
        albumArtElement.classList.remove('has-art');
        
        // Update document title
        document.title = 'Loading track...';
    }
    
    /**
     * Update the UI with track information
     * @param {Object} track - The track object with metadata
     */
    function updateTrackInfo(track) {
        if (!track || !track.metadata) return;
        
        // First show loading state
        showLoadingState();
        
        // Use setTimeout to give the shimmer effect time to be visible
        setTimeout(() => {
            // Update text information
            songTitleElement.textContent = track.metadata.title || 'Unknown Title';
            
            // Handle multiple artists if available
            if (track.metadata.artistList && track.metadata.artistList.length > 0) {
                // Log raw artist list for debugging
                console.log("Raw artist list:", track.metadata.artistList);
                
                // Display all artists as a formatted string
                songArtistElement.textContent = MetadataManager.formatArtistList(track.metadata.artistList);
                console.log("Formatted artist display:", songArtistElement.textContent);
                
                // Store the full list in data attribute for potential hover/click features
                songArtistElement.setAttribute('data-artists', JSON.stringify(track.metadata.artistList));
                
                // Add a tooltip showing all artists
                songArtistElement.title = "Artists: " + track.metadata.artistList.join(", ");
            } else {
                songArtistElement.textContent = track.metadata.artist || 'Unknown Artist';
            }
            
            songAlbumElement.textContent = track.metadata.album || 'Unknown Album';
            
            // Update album art
            if (track.metadata.picture) {
                albumArtElement.innerHTML = `<img src="${track.metadata.picture}" alt="Album art" class="fade-in">`;
                albumArtElement.classList.add('has-art');
            } else {
                albumArtElement.innerHTML = `<span class="material-icons-round md-80">album</span>`;
                albumArtElement.classList.remove('has-art');
            }
            
            // Update total duration
            totalTimeElement.textContent = MetadataManager.formatTime(track.metadata.duration);
            
            // Update document title
            document.title = `${track.metadata.title} - ${track.metadata.artist || 'Unknown Artist'}`;
            
            // Enable appropriate controls
            enableControls();
        }, 750); // Show loading state for 750ms before displaying actual content
    }
    
    /**
     * Play audio
     * @returns {Promise} - Play promise from audio element
     */
    function play() {
        isPlaying = true;
        playPauseBtn.innerHTML = '<span class="material-icons-round md-36">pause</span>';
        return audioElement.play();
    }
    
    /**
     * Pause audio
     */
    function pause() {
        isPlaying = false;
        playPauseBtn.innerHTML = '<span class="material-icons-round md-36">play_arrow</span>';
        audioElement.pause();
        
        // Also pause the visualizer when audio is paused
        if (VisualizerManager && equalizerInitialized) {
            VisualizerManager.stop();
        }
    }
    
    /**
     * Toggle between play and pause
     */
    function togglePlayPause() {
        if (isPlaying) {
            pause();
        } else {
            play().catch(error => console.error("Playback error:", error));
            
            // Resume visualizer when playing
            if (VisualizerManager && equalizerInitialized) {
                VisualizerManager.start();
            }
        }
    }
    
    /**
     * Play the next track in queue
     */
    function playNext() {
        try {
            const nextTrack = QueueManager.nextTrack();
            if (nextTrack) {
                console.log("Playing next track:", nextTrack.metadata ? nextTrack.metadata.title : "Unknown");
                loadAndPlayTrack(nextTrack);
            } else {
                console.log("No next track available");
                UIManager.showNotification("End of queue reached", "info");
            }
        } catch (error) {
            console.error("Error playing next track:", error);
            UIManager.showNotification("Error playing next track", "error");
        }
    }
    
    /**
     * Play the previous track in queue
     */
    function playPrevious() {
        try {
            // If current time > 3 seconds, restart current track instead
            if (audioElement.currentTime > 3) {
                console.log("Restarting current track");
                audioElement.currentTime = 0;
                return;
            }
            
            const prevTrack = QueueManager.prevTrack();
            if (prevTrack) {
                console.log("Playing previous track:", prevTrack.metadata ? prevTrack.metadata.title : "Unknown");
                loadAndPlayTrack(prevTrack);
            } else {
                console.log("No previous track available");
                UIManager.showNotification("Beginning of queue reached", "info");
            }
        } catch (error) {
            console.error("Error playing previous track:", error);
            UIManager.showNotification("Error playing previous track", "error");
        }
    }
    
    /**
     * Rewind 10 seconds
     */
    function rewind() {
        audioElement.currentTime = Math.max(0, audioElement.currentTime - 10);
    }
    
    /**
     * Fast forward 10 seconds
     */
    function fastForward() {
        audioElement.currentTime = Math.min(audioElement.duration, audioElement.currentTime + 10);
    }
    
    /**
     * Update the volume based on slider value
     */
    function updateVolume() {
        // Set the audio volume
        audioElement.volume = volumeSlider.value;
        
        // Update the visual slider fill using CSS variable
        const volumePercentage = volumeSlider.value * 100;
        volumeSlider.style.setProperty('--volume-percentage', `${volumePercentage}%`);
    }
    
    /**
     * Update progress bar and time display
     */
    function updateProgress() {
        if (!audioElement.duration) return;
        
        const percent = (audioElement.currentTime / audioElement.duration) * 100;
        progressBar.style.width = `${percent}%`;
        
        currentTimeElement.textContent = MetadataManager.formatTime(audioElement.currentTime);
    }
    
    // Variable to track if user is dragging progress bar
    let isDraggingProgress = false;
    
    /**
     * Seek to position when clicking or dragging on progress bar
     * @param {Event} event - Click/drag event
     */
    function seekToPosition(event) {
        if (!audioElement.duration) return;
        
        const rect = progressContainer.getBoundingClientRect();
        const clickPosition = event.clientX - rect.left;
        const progressWidth = rect.width;
        
        // Calculate seek time based on position
        const seekTime = (clickPosition / progressWidth) * audioElement.duration;
        
        // Ensure we're in bounds
        if (seekTime >= 0 && seekTime <= audioElement.duration) {
            audioElement.currentTime = seekTime;
        }
    }
    
    /**
     * Handle mouse down to start dragging on progress bar
     * @param {Event} event - Mouse down event 
     */
    function handleProgressMouseDown(event) {
        // Only handle left mouse button
        if (event.button !== 0) return;
        
        // Start dragging
        isDraggingProgress = true;
        
        // Seek on initial press
        seekToPosition(event);
        
        // Add mouse move and mouse up listeners to document
        document.addEventListener('mousemove', handleProgressMouseMove);
        document.addEventListener('mouseup', handleProgressMouseUp);
        
        // Prevent default behavior
        event.preventDefault();
    }
    
    /**
     * Handle mouse move during progress bar drag
     * @param {Event} event - Mouse move event
     */
    function handleProgressMouseMove(event) {
        if (isDraggingProgress) {
            seekToPosition(event);
            event.preventDefault();
        }
    }
    
    /**
     * Handle mouse up to end progress bar drag
     * @param {Event} event - Mouse up event
     */
    function handleProgressMouseUp(event) {
        if (isDraggingProgress) {
            // End dragging
            isDraggingProgress = false;
            
            // Remove document listeners
            document.removeEventListener('mousemove', handleProgressMouseMove);
            document.removeEventListener('mouseup', handleProgressMouseUp);
            
            event.preventDefault();
        }
    }
    
    /**
     * Handle track end by playing next track
     */
    function handleTrackEnd() {
        try {
            console.log("Track ended, attempting to play next track");
            const nextTrack = QueueManager.nextTrack();
            if (nextTrack) {
                // Small delay to ensure clean transition
                setTimeout(() => {
                    loadAndPlayTrack(nextTrack);
                }, 50);
            } else {
                console.log("End of queue reached");
                // Reset UI for end of queue
                isPlaying = false;
                playPauseBtn.innerHTML = '<span class="material-icons-round md-36">play_arrow</span>';
            }
        } catch (error) {
            console.error("Error during track end handling:", error);
        }
    }
    
    /**
     * Enable controls once audio is ready to play
     */
    function enablePlayback() {
        enableControls();
        play().catch(error => console.error("Autoplay prevented:", error));
    }
    
    /**
     * Enable or disable controls based on current state
     */
    function enableControls() {
        // Enable play/pause and timeline controls if we have a track
        const hasTrack = !!currentTrack;
        playPauseBtn.disabled = !hasTrack;
        rewindBtn.disabled = !hasTrack;
        forwardBtn.disabled = !hasTrack;
        
        // Enable prev/next based on queue position
        prevBtn.disabled = !QueueManager.hasPrev();
        nextBtn.disabled = !QueueManager.hasNext();
    }
    
    /**
     * Handle audio loading errors
     */
    function handleError() {
        console.error("Audio error:", audioElement.error);
        UIManager.showNotification("Error playing track: " + (audioElement.error ? audioElement.error.message : "Unknown error"), "error");
    }
    
    /**
     * Adjust a specific equalizer band
     * @param {string} bandName - Name of the band to adjust
     * @param {number} value - Value to set (-12 to +12 dB)
     * @returns {boolean} - Success or failure
     */
    function adjustEqualizerBand(bandName, value) {
        if (!equalizerInitialized) {
            initializeEqualizer();
        }
        return EqualizerManager.adjustBand(bandName, value);
    }
    
    /**
     * Apply an equalizer preset
     * @param {string} presetName - Name of the preset to apply
     */
    function applyEqualizerPreset(presetName) {
        if (!equalizerInitialized) {
            initializeEqualizer();
        }
        EqualizerManager.applyPreset(presetName);
    }
    
    /**
     * Reset equalizer to flat response
     */
    function resetEqualizer() {
        if (!equalizerInitialized) {
            initializeEqualizer();
        }
        EqualizerManager.resetEqualizer();
    }
    
    /**
     * Get current equalizer band settings
     * @returns {Array} - Array of band objects with name, frequency and gain values
     */
    function getEqualizerSettings() {
        if (!equalizerInitialized) {
            return [];
        }
        return EqualizerManager.getBandSettings();
    }
    
    // Initialize the player
    init();
    
    // Public API
    return {
        loadAndPlayTrack,
        play,
        pause,
        playNext,
        playPrevious,
        enableControls,
        showLoadingState,  // Export the loading state function
        
        // Equalizer functions
        adjustEqualizerBand,
        applyEqualizerPreset,
        resetEqualizer,
        getEqualizerSettings
    };
})();
