/**
 * Queue Module - Manages the music queue functionality
 */
const QueueManager = (function() {
    // Queue state
    let queue = [];
    let currentIndex = -1;
    
    // DOM elements
    const queueListElement = document.getElementById('queue-list');
    
    /**
     * Add a track to the queue
     * @param {Object} track - The track object with metadata and file
     * @returns {number} - Index of the added track
     */
    function addTrack(track) {
        queue.push(track);
        updateQueueDisplay();
        
        // If this is the first track, set current index to 0
        if (queue.length === 1) {
            currentIndex = 0;
            return 0;
        }
        
        return queue.length - 1;
    }
    
    /**
     * Add multiple tracks to the queue
     * @param {Array} tracks - Array of track objects
     */
    function addTracks(tracks) {
        // If queue was empty, we'll want to start playing the first added track
        const wasEmpty = queue.length === 0;
        
        queue = queue.concat(tracks);
        updateQueueDisplay();
        
        // If queue was empty before, set current index to 0
        if (wasEmpty && tracks.length > 0) {
            currentIndex = 0;
        }
    }
    
    /**
     * Get the current track
     * @returns {Object|null} - Current track or null if queue is empty
     */
    function getCurrentTrack() {
        if (currentIndex < 0 || currentIndex >= queue.length) {
            return null;
        }
        return queue[currentIndex];
    }
    
    /**
     * Move to the next track in queue
     * @returns {Object|null} - Next track or null if end of queue
     */
    function nextTrack() {
        if (currentIndex < queue.length - 1) {
            currentIndex++;
            updateQueueDisplay();
            return getCurrentTrack();
        }
        return null;
    }
    
    /**
     * Move to the previous track in queue
     * @returns {Object|null} - Previous track or null if at beginning of queue
     */
    function prevTrack() {
        if (currentIndex > 0) {
            currentIndex--;
            updateQueueDisplay();
            return getCurrentTrack();
        }
        return null;
    }
    
    /**
     * Play a specific track from the queue by index
     * @param {number} index - Index of track to play
     * @returns {Object|null} - The selected track or null if invalid
     */
    function playTrack(index) {
        if (index >= 0 && index < queue.length) {
            currentIndex = index;
            updateQueueDisplay();
            return getCurrentTrack();
        }
        return null;
    }
    
    /**
     * Check if there is a next track available
     * @returns {boolean} - True if next track exists
     */
    function hasNext() {
        return currentIndex < queue.length - 1;
    }
    
    /**
     * Check if there is a previous track available
     * @returns {boolean} - True if previous track exists
     */
    function hasPrev() {
        return currentIndex > 0;
    }
    
    /**
     * Get the entire queue
     * @returns {Array} - Array of track objects
     */
    function getQueue() {
        return [...queue];
    }
    
    /**
     * Clear the entire queue
     */
    function clearQueue() {
        queue = [];
        currentIndex = -1;
        updateQueueDisplay();
    }
    
    /**
     * Update the queue display in the UI
     */
    function updateQueueDisplay() {
        // Clear the current list
        queueListElement.innerHTML = '';
        
        // If queue is empty, show empty state
        if (queue.length === 0) {
            queueListElement.innerHTML = `
                <li class="queue-empty text-center py-5">
                    <p>Your queue is empty</p>
                    <p class="text-muted">Upload music to get started</p>
                </li>
            `;
            return;
        }
        
        // Add each track to the list
        queue.forEach((track, index) => {
            const isActive = index === currentIndex;
            const queueItem = document.createElement('li');
            queueItem.className = `queue-item${isActive ? ' active' : ''}`;
            queueItem.dataset.index = index;
            
            queueItem.innerHTML = `
                <div class="queue-item-img">
                    ${track.metadata.picture 
                        ? `<img src="${track.metadata.picture}" alt="Album art">` 
                        : `<span class="material-icons-round">music_note</span>`}
                </div>
                <div class="queue-item-info">
                    <div class="queue-item-title">${track.metadata.title}</div>
                    <div class="queue-item-artist">${track.metadata.artistList && track.metadata.artistList.length > 0 
                        ? MetadataManager.formatArtistList(track.metadata.artistList) 
                        : track.metadata.artist}</div>
                </div>
                <div class="queue-item-duration">${MetadataManager.formatTime(track.metadata.duration)}</div>
            `;
            
            // Add click event to play this track
            queueItem.addEventListener('click', () => {
                const clickedIndex = parseInt(queueItem.dataset.index);
                const track = playTrack(clickedIndex);
                if (track) {
                    PlayerManager.loadAndPlayTrack(track);
                }
            });
            
            queueListElement.appendChild(queueItem);
        });
    }
    
    // Public API
    return {
        addTrack,
        addTracks,
        getCurrentTrack,
        nextTrack,
        prevTrack,
        playTrack,
        hasNext,
        hasPrev,
        getQueue,
        clearQueue,
        updateQueueDisplay
    };
})();
