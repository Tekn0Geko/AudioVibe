/**
 * UI Manager - Handles UI interactions and animations
 */
const UIManager = (function() {
    // DOM Elements
    const fileUploadInput = document.getElementById('file-upload');
    const dragDropZone = document.getElementById('drag-drop-zone');
    
    // Tab elements
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanels = document.querySelectorAll('.tab-panel');
    
    // Equalizer elements
    const eqPresetSelect = document.getElementById('eq-preset');
    const eqResetButton = document.getElementById('eq-reset');
    const eqSliders = document.querySelectorAll('.eq-slider');
    
    /**
     * Initialize UI event listeners
     */
    function init() {
        // File upload input change event
        fileUploadInput.addEventListener('change', handleFileUpload);
        
        // Drag and drop events
        dragDropZone.addEventListener('dragover', handleDragOver);
        dragDropZone.addEventListener('dragleave', handleDragLeave);
        dragDropZone.addEventListener('drop', handleDrop);
        
        // Initialize tooltips if Bootstrap is available
        if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        }
        
        // Initialize tab switching
        initializeTabs();
        
        // Initialize equalizer controls
        initializeEqualizerControls();
    }
    
    /**
     * Initialize tab switching functionality
     */
    function initializeTabs() {
        // Add event listeners to tab buttons
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                const targetId = this.dataset.target;
                
                // Remove active class from all buttons and panels
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabPanels.forEach(panel => panel.classList.remove('active'));
                
                // Add active class to clicked button and corresponding panel
                this.classList.add('active');
                document.getElementById(targetId).classList.add('active');
            });
        });
    }
    
    /**
     * Initialize equalizer UI controls
     */
    function initializeEqualizerControls() {
        if (!eqPresetSelect || !eqResetButton) {
            console.log("Equalizer controls not found in DOM, will initialize later");
            return;
        }
        
        // Add event listeners for equalizer preset selection
        eqPresetSelect.addEventListener('change', function() {
            const preset = this.value;
            PlayerManager.applyEqualizerPreset(preset);
            updateEqualizerSliders();
            showNotification(`Applied ${preset} equalizer preset`, 'info');
        });
        
        // Add event listener for reset button
        eqResetButton.addEventListener('click', function() {
            PlayerManager.resetEqualizer();
            eqPresetSelect.value = 'flat';
            updateEqualizerSliders();
            showNotification('Equalizer reset to flat response', 'info');
        });
        
        // Add event listeners for individual sliders
        eqSliders.forEach(slider => {
            // Update value display when slider changes
            slider.addEventListener('input', function() {
                const band = this.dataset.band;
                const value = parseInt(this.value);
                
                // Update the visual display
                const valueDisplay = this.parentElement.querySelector('.eq-value');
                if (valueDisplay) {
                    valueDisplay.textContent = `${value > 0 ? '+' : ''}${value} dB`;
                }
                
                // Apply the change to the equalizer
                PlayerManager.adjustEqualizerBand(band, value);
                
                // Set preset to custom when user adjusts sliders
                if (eqPresetSelect.value !== 'custom') {
                    // Add a custom option if it doesn't exist
                    if (!document.querySelector('option[value="custom"]')) {
                        const customOption = document.createElement('option');
                        customOption.value = 'custom';
                        customOption.textContent = 'Custom';
                        eqPresetSelect.appendChild(customOption);
                    }
                    eqPresetSelect.value = 'custom';
                }
            });
        });
        
        console.log("Equalizer controls initialized");
    }
    
    /**
     * Update equalizer sliders to match current settings
     */
    function updateEqualizerSliders() {
        const settings = PlayerManager.getEqualizerSettings();
        
        settings.forEach(band => {
            const slider = document.getElementById(`eq-${band.name}`);
            const valueDisplay = slider?.parentElement.querySelector('.eq-value');
            
            if (slider) {
                slider.value = band.gain;
            }
            
            if (valueDisplay) {
                valueDisplay.textContent = `${band.gain > 0 ? '+' : ''}${band.gain} dB`;
            }
        });
    }
    
    /**
     * Handle file upload from input element
     * @param {Event} event - Change event
     */
    async function handleFileUpload(event) {
        const files = event.target.files;
        
        if (files.length === 0) return;
        
        // Process uploaded files
        await processFiles(files);
        
        // Reset the input so same file can be uploaded again
        fileUploadInput.value = '';
    }
    
    /**
     * Handle dragover event
     * @param {Event} event - Dragover event
     */
    function handleDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        dragDropZone.classList.add('drag-over');
    }
    
    /**
     * Handle dragleave event
     * @param {Event} event - Dragleave event
     */
    function handleDragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        dragDropZone.classList.remove('drag-over');
    }
    
    /**
     * Handle drop event
     * @param {Event} event - Drop event
     */
    async function handleDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        dragDropZone.classList.remove('drag-over');
        
        const files = event.dataTransfer.files;
        
        if (files.length === 0) return;
        
        // Process dropped files
        await processFiles(files);
    }
    
    /**
     * Process audio files and add to queue
     * @param {FileList} files - List of files to process
     */
    async function processFiles(files) {
        showNotification(`Processing ${files.length} file(s)...`, 'info');
        
        // Support audio files even if MIME type is not set correctly
        const audioFiles = Array.from(files).filter(file => {
            // Check by MIME type first
            if (file.type.startsWith('audio/')) return true;
            
            // Also check by extension as fallback
            const ext = file.name.split('.').pop().toLowerCase();
            const audioExts = ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac', 'wma'];
            return audioExts.includes(ext);
        });
        
        console.log(`Found ${audioFiles.length} audio files to process`, audioFiles);
        
        if (audioFiles.length === 0) {
            showNotification('No audio files found. Please upload audio files.', 'error');
            return;
        }
        
        // Show loading state if queue is empty (we're about to play the first track)
        const isQueueEmpty = QueueManager.getQueue().length === 0;
        if (isQueueEmpty && typeof PlayerManager.showLoadingState === 'function') {
            // Show loading state immediately to provide visual feedback
            PlayerManager.showLoadingState();
        }
        
        const tracks = [];
        let failedCount = 0;
        
        // Process files and create track objects, even if metadata extraction fails
        for (const file of audioFiles) {
            console.log(`Processing file: ${file.name}`, file);
            
            try {
                // Basic metadata based on filename (fallback)
                const basicMetadata = {
                    title: file.name.replace(/\.[^/.]+$/, ""),
                    artist: "Unknown Artist",
                    album: "Unknown Album",
                    duration: 0,
                    picture: null
                };
                
                // Try to extract metadata 
                let metadata;
                try {
                    metadata = await MetadataManager.extractMetadata(file);
                    console.log(`Extracted metadata for ${file.name}:`, metadata);
                } catch (metadataError) {
                    console.error(`Failed to extract metadata for ${file.name}:`, metadataError);
                    metadata = basicMetadata;
                    failedCount++;
                }
                
                // Create track object regardless of metadata success
                tracks.push({
                    file: file,
                    metadata: metadata || basicMetadata
                });
            } catch (error) {
                console.error(`Error processing ${file.name}:`, error);
                failedCount++;
            }
        }
        
        // Add all processed tracks to queue
        if (tracks.length > 0) {
            const wasEmpty = QueueManager.getQueue().length === 0;
            QueueManager.addTracks(tracks);
            
            // Show appropriate notification
            if (failedCount > 0) {
                showNotification(`Added ${tracks.length} track(s) to queue with ${failedCount} metadata errors`, 'info');
            } else {
                showNotification(`Added ${tracks.length} track${tracks.length > 1 ? 's' : ''} to queue`, 'success');
            }
            
            // If queue was empty, start playing the first track
            if (wasEmpty) {
                const currentTrack = QueueManager.getCurrentTrack();
                if (currentTrack) {
                    PlayerManager.loadAndPlayTrack(currentTrack);
                }
            }
        } else if (failedCount > 0) {
            showNotification(`Failed to process ${failedCount} file(s)`, 'error');
        }
    }
    
    /**
     * Show notification message
     * @param {string} message - Notification message
     * @param {string} type - Notification type (info, success, error)
     */
    function showNotification(message, type = 'info') {
        // Check if Bootstrap toast is available
        if (typeof bootstrap !== 'undefined' && bootstrap.Toast) {
            // Create toast container if it doesn't exist
            let toastContainer = document.querySelector('.toast-container');
            if (!toastContainer) {
                toastContainer = document.createElement('div');
                toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
                document.body.appendChild(toastContainer);
            }
            
            // Create toast element
            const toastEl = document.createElement('div');
            toastEl.className = `toast align-items-center text-white bg-${type === 'error' ? 'danger' : type} border-0`;
            toastEl.setAttribute('role', 'alert');
            toastEl.setAttribute('aria-live', 'assertive');
            toastEl.setAttribute('aria-atomic', 'true');
            
            toastEl.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            `;
            
            toastContainer.appendChild(toastEl);
            
            // Initialize and show toast
            const toast = new bootstrap.Toast(toastEl, {
                autohide: true,
                delay: 3000
            });
            toast.show();
            
            // Remove toast from DOM after it's hidden
            toastEl.addEventListener('hidden.bs.toast', () => {
                toastEl.remove();
            });
        } else {
            // Fallback to console if Bootstrap is not available
            console.log(`[${type.toUpperCase()}] ${message}`);
            
            // Also create a simple notification element
            const notificationEl = document.createElement('div');
            notificationEl.className = `simple-notification ${type}`;
            
            // Add icon based on notification type
            const iconName = type === 'error' ? 'error' : 
                            type === 'success' ? 'check_circle' : 'info';
            
            notificationEl.innerHTML = `
                <span class="material-icons-round notification-icon">${iconName}</span>
                <span class="notification-text">${message}</span>
            `;
            
            document.body.appendChild(notificationEl);
            
            // Add some basic styles
            notificationEl.style.position = 'fixed';
            notificationEl.style.bottom = '20px';
            notificationEl.style.right = '20px';
            notificationEl.style.padding = '12px 16px';
            notificationEl.style.borderRadius = '8px';
            notificationEl.style.color = '#fff';
            notificationEl.style.backgroundColor = type === 'error' ? '#CF6679' : type === 'success' ? '#03DAC5' : '#3700B3';
            notificationEl.style.zIndex = '9999';
            notificationEl.style.opacity = '0';
            notificationEl.style.transition = 'opacity 0.3s ease-in-out';
            notificationEl.style.display = 'flex';
            notificationEl.style.alignItems = 'center';
            notificationEl.style.gap = '10px';
            notificationEl.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.2)';
            
            // Animate in
            setTimeout(() => {
                notificationEl.style.opacity = '1';
            }, 10);
            
            // Remove after 3 seconds
            setTimeout(() => {
                notificationEl.style.opacity = '0';
                setTimeout(() => {
                    notificationEl.remove();
                }, 300);
            }, 3000);
        }
    }
    
    // Initialize the UI
    init();
    
    // Public API
    return {
        showNotification,
        updateEqualizerSliders,
        initializeEqualizerControls
    };
})();

// Execute when DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Log initialization message
    console.log('Music Player initialized');
    
    // Check if jsmediatags is loaded
    if (typeof jsmediatags === 'undefined') {
        console.error('jsmediatags library is not loaded!');
        UIManager.showNotification('Media tags library not loaded. Some features may not work.', 'error');
    } else {
        console.log('jsmediatags library loaded successfully', jsmediatags);
    }
});
