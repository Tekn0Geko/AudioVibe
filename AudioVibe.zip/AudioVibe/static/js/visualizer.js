/**
 * Audio Visualizer Module - Renders real-time audio visualizations
 */
const VisualizerManager = (function() {
    // Canvas and context
    let canvas = null;
    let ctx = null;
    
    // Analyzer node from equalizer
    let analyser = null;
    
    // Animation frame request ID
    let animationId = null;
    
    // Visualization settings
    let settings = {
        active: true,
        barWidth: 4,
        barSpacing: 1,
        barColor: '#7f5af0',
        barColorEnd: '#6b48e0',
        barStyle: 'gradient', // 'solid', 'gradient'
        barSmoothing: 0.5,
        barFalloff: 0.05,
        fftSize: 256
    };
    
    // Variables to track previous data for smoothing
    let previousData = null;
    
    /**
     * Initialize the visualizer with a canvas element and analyser node
     * @param {HTMLCanvasElement} canvasElement - The canvas to draw on
     * @param {AnalyserNode} analyserNode - Audio analyser node from equalizer
     */
    function init(canvasElement, analyserNode) {
        if (!canvasElement || !analyserNode) {
            console.error('Canvas element or analyser node not provided');
            return false;
        }
        
        canvas = canvasElement;
        ctx = canvas.getContext('2d');
        analyser = analyserNode;
        
        // Set analyzer properties
        analyser.fftSize = settings.fftSize * 2; // Double fftSize to get more frequency data
        
        // Set up resize handling
        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();
        
        console.log('Visualizer initialized');
        return true;
    }
    
    /**
     * Start the visualization animation
     * @returns {boolean} - Success status
     */
    function start() {
        if (!analyser || !canvas) {
            console.error('Visualizer not properly initialized');
            return false;
        }
        
        if (animationId) {
            cancelAnimationFrame(animationId);
        }
        
        // Begin animation loop
        draw();
        return true;
    }
    
    /**
     * Stop the visualization animation
     */
    function stop() {
        if (animationId) {
            cancelAnimationFrame(animationId);
            animationId = null;
            
            // Clear the canvas
            if (ctx) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        }
    }
    
    /**
     * Resize the canvas to match its display size
     */
    function resizeCanvas() {
        if (!canvas) return;
        
        // Get the device pixel ratio
        const dpr = window.devicePixelRatio || 1;
        
        // Set canvas dimensions based on its display size
        const displayWidth = Math.floor(canvas.clientWidth * dpr);
        const displayHeight = Math.floor(canvas.clientHeight * dpr);
        
        // Update canvas size if it doesn't match
        if (canvas.width !== displayWidth || canvas.height !== displayHeight) {
            canvas.width = displayWidth;
            canvas.height = displayHeight;
        }
    }
    
    /**
     * Draw the visualization on the canvas
     */
    function draw() {
        if (!ctx || !analyser || !settings.active) return;
        
        // Schedule next frame
        animationId = requestAnimationFrame(draw);
        
        // Create array for frequency data
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        
        // Get the frequency data
        analyser.getByteFrequencyData(dataArray);
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Apply smoothing if we have previous data
        let smoothedData = dataArray;
        if (previousData && settings.barSmoothing > 0) {
            smoothedData = smoothData(dataArray, previousData, settings.barSmoothing);
        }
        previousData = new Uint8Array(smoothedData);
        
        // Set up for drawing bars
        const barCount = settings.fftSize / 2; // Use half the fftSize for bars
        const totalWidth = (settings.barWidth + settings.barSpacing) * barCount;
        const barHeightMultiplier = canvas.height / 255; // Map 0-255 to canvas height
        
        // Center bars in canvas
        const startX = (canvas.width - totalWidth) / 2;
        
        // Draw each bar
        for (let i = 0; i < barCount; i++) {
            // Get frequency data (use logarithmic scaling for more natural-looking visualization)
            const dataIndex = Math.floor(i * (bufferLength / barCount));
            let barHeight = smoothedData[dataIndex] * barHeightMultiplier;
            
            // Apply falloff effect (bars appear to fall more naturally)
            if (previousData && settings.barFalloff > 0) {
                const prevHeight = previousData[dataIndex] * barHeightMultiplier;
                if (barHeight < prevHeight) {
                    barHeight = Math.max(barHeight, prevHeight - (prevHeight * settings.barFalloff));
                }
            }
            
            const x = startX + i * (settings.barWidth + settings.barSpacing);
            const y = canvas.height - barHeight;
            
            // Draw bar with specified style
            if (settings.barStyle === 'gradient') {
                // Create gradient
                const gradient = ctx.createLinearGradient(0, canvas.height, 0, y);
                gradient.addColorStop(0, settings.barColor);
                gradient.addColorStop(1, settings.barColorEnd);
                ctx.fillStyle = gradient;
            } else {
                ctx.fillStyle = settings.barColor;
            }
            
            // Draw rounded bars
            ctx.beginPath();
            ctx.roundRect(x, y, settings.barWidth, barHeight, [settings.barWidth / 2, settings.barWidth / 2, 0, 0]);
            ctx.fill();
        }
    }
    
    /**
     * Smooth data arrays for more fluid visualization
     * @param {Uint8Array} current - Current data array
     * @param {Uint8Array} previous - Previous data array
     * @param {number} smoothingFactor - Amount of smoothing (0-1)
     * @returns {Uint8Array} - Smoothed data array
     */
    function smoothData(current, previous, smoothingFactor) {
        if (current.length !== previous.length) return current;
        
        const result = new Uint8Array(current.length);
        
        for (let i = 0; i < current.length; i++) {
            result[i] = Math.round(current[i] * (1 - smoothingFactor) + previous[i] * smoothingFactor);
        }
        
        return result;
    }
    
    /**
     * Update visualization settings
     * @param {Object} newSettings - New settings to apply
     */
    function updateSettings(newSettings) {
        settings = {...settings, ...newSettings};
        
        // Update analyser FFT size if it changed
        if (analyser && settings.fftSize && analyser.fftSize !== settings.fftSize * 2) {
            analyser.fftSize = settings.fftSize * 2;
        }
    }
    
    /**
     * Clean up resources when visualizer is no longer needed
     */
    function cleanup() {
        stop();
        window.removeEventListener('resize', resizeCanvas);
        analyser = null;
        canvas = null;
        ctx = null;
    }
    
    // Public API
    return {
        init,
        start,
        stop,
        updateSettings,
        cleanup
    };
})();